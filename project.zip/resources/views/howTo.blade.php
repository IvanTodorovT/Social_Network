@extends('layouts.app')
@section('content')


This is how an upload form is added

<section id='uploadForm'></section>

<script type="text/javascript" src="js/addUploadForm.js"></script>

The path to the uploaded images is:
$path = resource_path() . DIRECTORY_SEPARATOR . 'uploads';